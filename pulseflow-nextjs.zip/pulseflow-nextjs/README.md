# PulseFlow — Next.js landing page

Responsive PulseFlow fintech SaaS landing page built with Next.js App Router, TypeScript, and custom CSS. Includes responsive navigation, dropdown menus, a sandbox request modal, metadata, metrics, and a responsive hero visual.

## Run locally

Requirements: Node.js 20.9+

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Production build

```bash
npm run build
npm start
```

## Customize

- `app/page.tsx` — page content and interactions
- `app/globals.css` — responsive styling
- `app/layout.tsx` — metadata
- `public/images/pulseflow-reference.png` — generated visual asset used in the hero

The sandbox form is a front-end demo and currently shows a local confirmation state; connect it to your API or CRM before production. The architecture-call CTA opens an email draft using a placeholder address that should be replaced with your real contact address. Finance brand names/logos are illustrative and do not imply endorsement.
