import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'PulseFlow — Liquidity without borders',
  description: 'Automate enterprise treasury, FX routing, and global payouts from one programmable interface.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
