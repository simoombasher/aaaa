'use client';

import { useState } from 'react';
import Image from 'next/image';
import { ArrowDownRight, ArrowRight, Check, ChevronDown, Globe2, Menu, X, Zap } from 'lucide-react';

const navItems = [
  { label: 'Product', items: ['Liquidity engine', 'Global payouts', 'FX optimization'] },
  { label: 'Solutions', items: ['For finance teams', 'For fintech platforms', 'For marketplaces'] },
  { label: 'Developers', items: ['API reference', 'Quickstart guide', 'System status'] },
  { label: 'Pricing', items: [] },
  { label: 'Resources', items: ['Documentation', 'Customer stories', 'Company'] },
];

const metrics = [
  { value: '$14.2B+', label: 'Settled volume', detail: 'across 62 corridors' },
  { value: '420ms', label: 'Average automated', detail: 'routing latency' },
  { value: '99.999%', label: 'Treasury API', detail: 'availability SLA' },
];

function BrandMark() {
  return <span className="brand-mark" aria-hidden="true"><span /><span /><span /><span /></span>;
}

export default function Home() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [sandboxOpen, setSandboxOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  function openSandbox() { setSandboxOpen(true); setSubmitted(false); }

  return (
    <main className="site-shell">
      <header className="navbar">
        <a className="brand" href="#home" aria-label="PulseFlow home"><BrandMark /><span>PulseFlow</span></a>
        <nav className={`nav-links ${mobileOpen ? 'nav-open' : ''}`} aria-label="Main navigation">
          {navItems.map((item) => item.items.length ? (
            <div className="nav-item" key={item.label}>
              <button className="nav-link" onClick={() => setActiveMenu(activeMenu === item.label ? null : item.label)} aria-expanded={activeMenu === item.label}>
                {item.label}<ChevronDown size={14} strokeWidth={1.8} />
              </button>
              {activeMenu === item.label && <div className="nav-dropdown">{item.items.map((sub) => <a href="#platform" key={sub} onClick={() => { setActiveMenu(null); setMobileOpen(false); }}>{sub}<ArrowRight size={14} /></a>)}</div>}
            </div>
          ) : <a className="nav-link" href="#pricing" key={item.label}>{item.label}</a>)}
          <div className="mobile-actions"><button className="text-button" onClick={openSandbox}>Sign in</button><button className="button button-dark" onClick={openSandbox}>Get started <ArrowRight size={16} /></button></div>
        </nav>
        <div className="nav-actions"><button className="text-button" onClick={openSandbox}>Sign in</button><button className="button button-dark nav-cta" onClick={openSandbox}>Get started <ArrowRight size={16} /></button></div>
        <button className="mobile-toggle" aria-label={mobileOpen ? 'Close navigation' : 'Open navigation'} onClick={() => setMobileOpen(!mobileOpen)}>{mobileOpen ? <X /> : <Menu />}</button>
      </header>

      <section className="hero" id="home">
        <div className="hero-copy">
          <div className="release-pill"><span className="pill-icon"><Zap size={13} fill="currentColor" /></span><span>V2.4 Released</span><span className="pill-dash">—</span><span>Zero-Latency Cross-Border Rails</span></div>
          <h1>Liquidity without<br className="desktop-break" /> borders.<br /><span>Unified in one engine.</span></h1>
          <p className="hero-description">Eliminate multi-day settlement drag. Automate enterprise treasury, FX hedging, and instant multi-node payouts from a single programmable interface.</p>
          <div className="hero-actions"><button className="button button-dark button-large" onClick={openSandbox}>Start Free Sandbox <ArrowRight size={17} /></button><a className="button button-light button-large" href="mailto:architecture@pulseflow.example?subject=PulseFlow%20Architecture%20Call">Book an Architecture Call</a></div>
          <div className="metrics" id="platform">{metrics.map((metric) => <div className="metric" key={metric.value}><strong>{metric.value}</strong><span>{metric.label}</span><span>{metric.detail}</span></div>)}</div>
          <div className="trust-block"><p>TRUSTED BY GLOBAL FINANCE TEAMS</p><div className="trust-logos" aria-label="Example integrations and finance brands"><span className="logo-stripe">stripe</span><span className="logo-wise">↗wise</span><span className="logo-jpm">J.P.Morgan</span><span className="logo-air">◈ airwallex</span><span className="logo-coin">coinbase</span><span className="logo-standard">◈ <span>standard<br />chartered</span></span></div></div>
        </div>

        <div className="hero-art" aria-label="Illustration of a connected global liquidity platform">
          <div className="art-glow" />
          <Image src="/images/pulseflow-reference.png" alt="PulseFlow global finance network with live transactions, connected currency routes, and liquidity dashboards" fill priority sizes="(max-width: 800px) 100vw, 62vw" className="art-image" />
          <div className="floating-chip chip-top"><span className="status-dot" />Live routing <strong>420ms</strong></div>
          <div className="floating-chip chip-bottom"><Globe2 size={15} /><span>62 global corridors</span><ArrowDownRight size={15} /></div>
        </div>
      </section>

      <section className="below-fold" id="pricing"><div className="below-icon"><Globe2 size={20} /></div><p>One engine. Every corridor.</p><h2>Move money at the speed<br />your business operates.</h2><span>Programmable liquidity infrastructure for teams building without borders.</span><button className="button button-dark" onClick={openSandbox}>Explore the platform <ArrowRight size={16} /></button></section>

      {sandboxOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setSandboxOpen(false); }}><section className="sandbox-modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button className="modal-close" onClick={() => setSandboxOpen(false)} aria-label="Close dialog"><X size={19} /></button><div className="modal-mark"><BrandMark /></div>{submitted ? <><div className="success-icon"><Check size={22} /></div><h2 id="modal-title">You’re on the list.</h2><p>We’ll send sandbox access details to <strong>{email}</strong>.</p><button className="button button-dark modal-submit" onClick={() => setSandboxOpen(false)}>Done <ArrowRight size={16} /></button></> : <><p className="eyebrow">PULSEFLOW DEVELOPER SANDBOX</p><h2 id="modal-title">Move money smarter.</h2><p>Get early access to programmable global liquidity. No commitment required.</p><form onSubmit={(event) => { event.preventDefault(); if (email.trim()) setSubmitted(true); }}><label htmlFor="email">Work email</label><input id="email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@company.com" required autoFocus /><button className="button button-dark modal-submit" type="submit">Request sandbox access <ArrowRight size={16} /></button></form><small>By continuing, you agree to receive product-related communications.</small></>}</section></div>}
      <footer><a className="brand footer-brand" href="#home"><BrandMark /><span>PulseFlow</span></a><span>Global liquidity, intelligently routed.</span><span>© 2026 PulseFlow</span></footer>
    </main>
  );
}
